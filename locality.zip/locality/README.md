### Simple Widget For Locality
- Weather
- DateTime
- City + Country

### Icons
Weather icons are from [**Meteocons** by Bas Milius](https://github.com/basmilius/weather-icons)