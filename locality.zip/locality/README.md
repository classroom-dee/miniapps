### Use
**If you have an older version, you need to delete the config file under c:/users/your-user-name/.locale_master.json**
1. `pip install -r requirements.txt --no-cache-dir`
2. `python main.py`

### Simple Widget For Locality
- Weather
- DateTime
- City + Country

### Todo
- Pack it up

### Icons
Weather icons are from [**Meteocons** by Bas Milius](https://github.com/basmilius/weather-icons)